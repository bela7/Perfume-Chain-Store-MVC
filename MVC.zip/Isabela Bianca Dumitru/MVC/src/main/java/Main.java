import Controller.LoginController;
import Model.Language;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Language language = new Language();
                LoginController loginController = new LoginController(language);
                loginController.initialize();
            }
        });
    }
}
