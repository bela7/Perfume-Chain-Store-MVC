package View;

import java.awt.*;
import javax.swing.*;

import java.util.ResourceBundle;
import java.util.Locale;
import javax.swing.table.DefaultTableModel;


public class AdministratorView extends JFrame  {

    private JTable userTable;
    private JTextField newUsernameField;
    private JTextField newPasswordField;
    private JComboBox<String> roleComboBox;
    private JTextField newIdField;
    private JTextField newIdMagazinField;
    private JButton addUserButton;
    private JButton deleteUserButton;
    private JButton updateUserButton;
    private JButton viewUserDetailsButton;
    private JLabel userIdLabel;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JLabel roleLabel;
    private JLabel idMagazinLabel;


    private ResourceBundle resourceBundle;
    private JButton btnEnglish;
    private JButton btnRomanian;
    private JButton btnFrench;
    private JButton btnSpanish;
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);

    private String user;

    public AdministratorView(String user) {
        initialize();
        setVisible(true);
        this.user=user;
        setTitle("Administrator - " + user);

    }
    private JPanel createLanguageButtonsPanel() {

        btnEnglish = new JButton("EN");
        btnRomanian = new JButton("RO");
        btnFrench = new JButton("FR");
        btnSpanish = new JButton("ES");
        Font buttonFont = new Font("Times New Roman", Font.BOLD, 13);
        btnEnglish.setFont(buttonFont);
        btnRomanian.setFont(buttonFont);
        btnFrench.setFont(buttonFont);
        btnSpanish.setFont(buttonFont);

        JPanel languageButtonsPanel = new JPanel();
        languageButtonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        languageButtonsPanel.setPreferredSize(new Dimension(800, 50));
        languageButtonsPanel.setBackground(Color.BLACK);

        btnEnglish.setPreferredSize(new Dimension(55, 30));
        btnRomanian.setPreferredSize(new Dimension(55, 30));
        btnFrench.setPreferredSize(new Dimension(55, 30));
        btnSpanish.setPreferredSize(new Dimension(55, 30));

        languageButtonsPanel.add(btnRomanian);
        languageButtonsPanel.add(btnEnglish);
        languageButtonsPanel.add(btnFrench);
        languageButtonsPanel.add(btnSpanish);

        return languageButtonsPanel;
    }



    private void initialize() {
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        Locale defaultLocale = new Locale("ro", "RO");
        resourceBundle = ResourceBundle.getBundle("LanguageBundle", defaultLocale);

        JLabel lbLoginForm = new JLabel("SEPHORA", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(800, 80));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.SOUTH);

        JPanel combinedHeaderPanel = new JPanel(new BorderLayout());
        combinedHeaderPanel.add(headerPanel, BorderLayout.NORTH);
        combinedHeaderPanel.add(createLanguageButtonsPanel(), BorderLayout.SOUTH);
        combinedHeaderPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));


        // User table
        userTable = new JTable();
        JScrollPane userTableScrollPane = new JScrollPane(userTable);
        userTable.setRowHeight(30);
        userTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        userTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));
        add(userTableScrollPane, BorderLayout.CENTER);

        // Controls panel
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(2, 2, 2, 2);

        // User ID
        userIdLabel = new JLabel("ID User:");
        userIdLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        controlsPanel.add(userIdLabel, gbc);
        gbc.gridx++;
        newIdField = new JTextField(10);
        controlsPanel.add(newIdField, gbc);

        // New username
        gbc.gridx = 0;
        gbc.gridy++;
        usernameLabel = new JLabel("Utilizator");
        usernameLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        controlsPanel.add(usernameLabel, gbc);
        gbc.gridx++;
        newUsernameField = new JTextField(10);
        controlsPanel.add(newUsernameField, gbc);

        // New password
        gbc.gridx = 0;
        gbc.gridy++;
        passwordLabel = new JLabel("Parola:");
        passwordLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        controlsPanel.add(passwordLabel, gbc);
        gbc.gridx++;
        newPasswordField = new JTextField(10);
        controlsPanel.add(newPasswordField, gbc);

        // Role
        gbc.gridx = 0;
        gbc.gridy++;
        roleLabel = new JLabel("Rol:");
        roleLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        controlsPanel.add(roleLabel, gbc);
        gbc.gridx++;
        roleComboBox = new JComboBox<>(new String[]{"Administrator", "Manager", "Angajat"});
        controlsPanel.add(roleComboBox, gbc);

        // ID Magazin
        gbc.gridx = 0;
        gbc.gridy++;
        idMagazinLabel = new JLabel("ID Magazin:");
        idMagazinLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        controlsPanel.add(idMagazinLabel, gbc);
        gbc.gridx++;
        newIdMagazinField = new JTextField(10);
        controlsPanel.add(newIdMagazinField, gbc);

        // Buttons
        addUserButton = new JButton("Adaugă utilizator");
        addUserButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        deleteUserButton = new JButton("Șterge utilizator");
        deleteUserButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        updateUserButton = new JButton("Actualizează utilizator");
        updateUserButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        viewUserDetailsButton = new JButton("Vizualizează detaliile unui utilizator");
        viewUserDetailsButton.setFont(new Font("Times New Roman", Font.BOLD, 14));


        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        controlsPanel.add(addUserButton, gbc);

        gbc.gridy++;
        controlsPanel.add(deleteUserButton, gbc);

        gbc.gridy++;
        controlsPanel.add(updateUserButton, gbc);

        gbc.gridy++;
        controlsPanel.add(viewUserDetailsButton, gbc);


        add(controlsPanel, BorderLayout.SOUTH);

        add(combinedHeaderPanel, BorderLayout.NORTH);

        setSize(850, 700);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);


    }

    public JButton getBtnEnglish() {
        return btnEnglish;
    }

    public JButton getBtnRomanian() {
        return btnRomanian;
    }

    public JButton getBtnFrench() {
        return btnFrench;
    }

    public JButton getBtnSpanish() {
        return btnSpanish;
    }

    public JTextField getUserIdField() {
        return newIdField;
    }

    public JTextField getUserNameField() {
        return newUsernameField;
    }

    public JTextField getPasswordField() {
        return newPasswordField;
    }

    public JComboBox<String> getRolComboBox() {
        return roleComboBox;
    }

    public JTextField getIdMagazinField() {
        return newIdMagazinField;
    }
    public JButton getAddUserButton() {
        return addUserButton;
    }

    public JButton getDeleteUserButton() {
        return deleteUserButton;
    }

    public JButton getUpdateUserButton() {
        return updateUserButton;
    }

    public JButton getViewUserDetailsButton() {
        return viewUserDetailsButton;
    }

    public JTable getUserTable() {
        return userTable;
    }

    public JLabel getUserIdLabel() {
        return userIdLabel;
    }

    public JLabel getUsernameLabel() {
        return usernameLabel;
    }

    public JLabel getPasswordLabel() {
        return passwordLabel;
    }

    public JLabel getRoleLabel() {
        return roleLabel;
    }

    public JLabel getIdMagazinLabel() {
        return idMagazinLabel;
    }

    public JComboBox<String> getRoleComboBox() {
        return roleComboBox;
    }

    public void updateResourceBundle(Locale locale) {
        setResourceBundle(ResourceBundle.getBundle("LanguageBundle", locale));
    }

    public void setResourceBundle(ResourceBundle bundle) {
        this.resourceBundle = bundle;
    }
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    public void showMessageDialog(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    public Object[] getRowData(int row) {
        int columnCount = userTable.getColumnCount();
        Object[] rowData = new Object[columnCount];

        for (int i = 0; i < columnCount; i++) {
            rowData[i] = userTable.getValueAt(row, i);
        }

        return rowData;
    }

    public void displayUsers(Object[][] users) {
        DefaultTableModel model = new DefaultTableModel(users, new Object[]{"ID user", "Username", "Parolă", "Rol", "ID magazin"});
        userTable.setModel(model);
    }

        public void showUserDetails(String userDetails) {
            JFrame userDetailsWindow = new JFrame("User Details");
            userDetailsWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            userDetailsWindow.setSize(500, 500);
            userDetailsWindow.setLocationRelativeTo(null);

            JTextArea userDetailsTextArea = new JTextArea(userDetails);
            userDetailsTextArea.setFont(new Font("Times New Roman", Font.BOLD, 14));
            userDetailsTextArea.setEditable(false);
            userDetailsTextArea.setBackground(Color.WHITE);
            userDetailsTextArea.setLineWrap(true);
            userDetailsTextArea.setWrapStyleWord(true);

            JScrollPane userDetailsScrollPane = new JScrollPane(userDetailsTextArea);
            userDetailsWindow.add(userDetailsScrollPane);

            userDetailsWindow.setVisible(true);
        }





    }
