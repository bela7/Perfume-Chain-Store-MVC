package View;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Locale;
import java.util.ResourceBundle;


public class ManagerView extends JFrame {
    private JTable table;
    private JComboBox<String> comboBoxMagazin, comboBoxSortarePret, comboBoxSortareNume, comboBoxProducator;
    private JTextField textFieldCautaDupaNume;
    private JButton btnCauta;
    private JButton btnFiltreaza;
    private JButton btnViewDetails;
    private JCheckBox chckbxDisponibil;
    private JLabel lblSortareNume;
    private JLabel lblSortarePret;
    private JLabel lblCautaDupaNume;

    private JTextArea textAreaParfumDetails;

    private JTextField textFieldPretMin;
    private JTextField textFieldPretMax;

    private JLabel lblPretMinim;
    private JLabel lblPretMaxim;
    private JLabel lblProducator;
    private JLabel lblDisponibilitate;
    private  JLabel lblMagazin;

    private ResourceBundle resourceBundle;
    private JButton btnEnglish;
    private JButton btnRomanian;
    private JButton btnFrench;
    private JButton btnSpanish;
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    String user;

    public ManagerView(String user) {
        this.user=user;
        initUI();
    }

    private JPanel createLanguageButtonsPanel() {

        btnEnglish = new JButton("EN");
        btnRomanian = new JButton("RO");
        btnFrench = new JButton("FR");
        btnSpanish = new JButton("ES");
        Font buttonFont = new Font("Times New Roman", Font.BOLD, 13);
        btnEnglish.setFont(buttonFont);
        btnRomanian.setFont(buttonFont);
        btnFrench.setFont(buttonFont);
        btnSpanish.setFont(buttonFont);

        JPanel languageButtonsPanel = new JPanel();
        languageButtonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        languageButtonsPanel.setPreferredSize(new Dimension(800, 50));
        languageButtonsPanel.setBackground(Color.BLACK);

        btnEnglish.setPreferredSize(new Dimension(55, 30));
        btnRomanian.setPreferredSize(new Dimension(55, 30));
        btnFrench.setPreferredSize(new Dimension(55, 30));
        btnSpanish.setPreferredSize(new Dimension(55, 30));

        languageButtonsPanel.add(btnRomanian);
        languageButtonsPanel.add(btnEnglish);
        languageButtonsPanel.add(btnFrench);
        languageButtonsPanel.add(btnSpanish);

        return languageButtonsPanel;
    }

    private void initUI() {
        setTitle("Manager - " + user);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1120, 660);
        setLocationRelativeTo(null);

        Locale defaultLocale = new Locale("ro", "RO");
        resourceBundle = ResourceBundle.getBundle("LanguageBundle", defaultLocale);

        JLabel lbLoginForm = new JLabel("SEPHORA", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(1000, 80));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.SOUTH);

        JPanel combinedHeaderPanel = new JPanel(new BorderLayout());
        combinedHeaderPanel.add(headerPanel, BorderLayout.NORTH);
        combinedHeaderPanel.add(createLanguageButtonsPanel(), BorderLayout.SOUTH);
        combinedHeaderPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(combinedHeaderPanel, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);

        // Tabel
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 0, 790, 460);
        table = new JTable();
        table.setRowHeight(30);
        table.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));

        table.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"Id Parfum", "Denumire", "Producător", "Pret", "Descriere", "Stoc"}
        ));

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(table);

        // ComboBox to select the magazin
        lblMagazin = new JLabel("Magazin:");
        lblMagazin.setBounds(840, 10, 100, 20);
        contentPane.add(lblMagazin);

        comboBoxMagazin = new JComboBox<String>();
        comboBoxMagazin.setBounds(900, 10, 150, 20);
        contentPane.add(comboBoxMagazin);

        // ComboBox for sorting by price
        lblSortarePret = new JLabel("Sortare preț:");
        lblSortarePret.setBounds(840, 60, 100, 20);
        contentPane.add(lblSortarePret);

        comboBoxSortarePret = new JComboBox<String>();
        comboBoxSortarePret.setBounds(960, 60, 100, 20);
        contentPane.add(comboBoxSortarePret);
        comboBoxSortarePret.addItem("Crescător");
        comboBoxSortarePret.addItem("Descrescător");

        // ComboBox for sorting by name
        lblSortareNume = new JLabel("Sortare denumire:");
        lblSortareNume.setBounds(840, 90, 100, 20);
        contentPane.add(lblSortareNume);

        comboBoxSortareNume = new JComboBox<String>();
        comboBoxSortareNume.setBounds(960, 90, 100, 20);
        contentPane.add(comboBoxSortareNume);


        // Search by name
        lblCautaDupaNume = new JLabel("Caută după nume:");
        lblCautaDupaNume.setBounds(840, 140, 100, 20);
        contentPane.add(lblCautaDupaNume);

        textFieldCautaDupaNume = new JTextField();
        textFieldCautaDupaNume.setBounds(940, 140, 150, 20);
        contentPane.add(textFieldCautaDupaNume);

        btnCauta = new JButton("Caută");
        btnCauta.setBounds(950, 170, 100, 23);
        contentPane.add(btnCauta);


        btnViewDetails = new JButton("Vizualizează detaliile unui parfum");
        btnViewDetails.setBounds(850, 210, 200, 23);
        contentPane.add(btnViewDetails);


        lblPretMinim = new JLabel("Preț minim:");
        lblPretMinim.setBounds(840, 260, 100, 20);
        contentPane.add(lblPretMinim);

        textFieldPretMin = new JTextField();
        textFieldPretMin.setBounds(950, 260, 100, 20);
        contentPane.add(textFieldPretMin);
        textFieldPretMin.setColumns(10);


        lblPretMaxim = new JLabel("Pret maxim:");
        lblPretMaxim.setBounds(840, 300, 100, 20);
        contentPane.add(lblPretMaxim);

        textFieldPretMax = new JTextField();
        textFieldPretMax.setBounds(950, 300, 100, 20);
        contentPane.add(textFieldPretMax);
        textFieldPretMax.setColumns(10);


        lblProducator = new JLabel("Producător:");
        lblProducator.setBounds(840, 350, 100, 20);
        contentPane.add(lblProducator);

        comboBoxProducator = new JComboBox<String>();
        comboBoxProducator.setBounds(900, 350, 150, 20);
        contentPane.add(comboBoxProducator);

        lblDisponibilitate = new JLabel("Disponibilitate:");
        lblDisponibilitate.setBounds(840, 390, 100, 20);
        contentPane.add(lblDisponibilitate);


        chckbxDisponibil = new JCheckBox("Disponibil");
        chckbxDisponibil.setBounds(850, 410, 100, 23);
        chckbxDisponibil.setBackground(Color.WHITE);
        contentPane.add(chckbxDisponibil);

        btnFiltreaza = new JButton("Filtrează");
        btnFiltreaza.setBounds(880, 440, 120, 23);
        contentPane.add(btnFiltreaza);


        textAreaParfumDetails= new JTextArea();
        textAreaParfumDetails.setBounds(830, 250, 250, 215);
        contentPane.add(textAreaParfumDetails);

        // Add all your components to mainPanel
        mainPanel.add(scrollPane);
        mainPanel.add(lblMagazin);
        mainPanel.add(comboBoxMagazin);
        mainPanel.add(lblSortarePret);
        mainPanel.add(comboBoxSortarePret);
        mainPanel.add(lblSortareNume);
        mainPanel.add(comboBoxSortareNume);
        mainPanel.add(lblCautaDupaNume);
        mainPanel.add(textFieldCautaDupaNume);
        mainPanel.add(btnCauta);
        mainPanel.add(btnViewDetails);
        mainPanel.add(lblPretMinim);
        mainPanel.add(textFieldPretMin);
        mainPanel.add(lblPretMaxim);
        mainPanel.add(textFieldPretMax);
        mainPanel.add(lblProducator);
        mainPanel.add(comboBoxProducator);
        mainPanel.add(lblDisponibilitate);
        mainPanel.add(chckbxDisponibil);
        mainPanel.add(btnFiltreaza);
        mainPanel.add(textAreaParfumDetails);

        contentPane.add(mainPanel, BorderLayout.CENTER);

        setContentPane(contentPane);
        setVisible(true);
    }


    public void updateResourceBundle(Locale locale) {
        setResourceBundle(ResourceBundle.getBundle("LanguageBundle", locale));
    }

    public void setResourceBundle(ResourceBundle bundle) {
        this.resourceBundle = bundle;
    }
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }


    public JComboBox<String> getComboBoxMagazin() {
        return comboBoxMagazin;
    }

    public JComboBox<String> getComboBoxSortarePret() {
        return comboBoxSortarePret;
    }

    public JComboBox<String> getComboBoxSortareNume() {
        return comboBoxSortareNume;
    }

    public JTextField getTextFieldCautaDupaNume() {
        return textFieldCautaDupaNume;
    }

    public JButton getBtnCauta() {
        return btnCauta;
    }

    public JLabel getLblMagazin() {
        return lblMagazin;
    }

    public JLabel getLblSortarePret() {
        return lblSortarePret;
    }

    public JLabel getLblSortareNume() {
        return lblSortareNume;
    }

    public JLabel getLblCautaDupaNume() {
        return lblCautaDupaNume;
    }

    public JButton getBtnViewDetails() {
        return btnViewDetails;
    }

    public JTextField getTextFieldPretMin() {
        return textFieldPretMin;
    }

    public JTextField getTextFieldPretMax() {
        return textFieldPretMax;
    }

    public JComboBox<String> getComboBoxProducator() {
        return comboBoxProducator;
    }

    public JCheckBox getChckbxDisponibil() {
        return chckbxDisponibil;
    }

    public JButton getBtnFiltreaza() {
        return btnFiltreaza;
    }

    public JTable getTable() {
        return table;
    }

    public JLabel getLblPretMinim() {
        return lblPretMinim;
    }

    public JLabel getLblPretMaxim() {
        return lblPretMaxim;
    }

    public JLabel getLblProducator() {
        return lblProducator;
    }

    public JLabel getLblDisponibilitate() {
        return lblDisponibilitate;
    }

    public JButton getBtnEnglish() {
        return btnEnglish;
    }

    public JButton getBtnRomanian() {
        return btnRomanian;
    }

    public JButton getBtnFrench() {
        return btnFrench;
    }

    public JButton getBtnSpanish() {
        return btnSpanish;
    }


    public Object[] getRowData(JTable table, int row) {
        int columnCount = table.getColumnCount();
        Object[] rowData = new Object[columnCount];

        for (int i = 0; i < columnCount; i++) {
            rowData[i] = table.getValueAt(row, i);
        }

        return rowData;
    }


    public void showParfumNotFoundMessage(){
        JOptionPane.showMessageDialog(this, "Nu s-a găsit parfumul introdus. Vă rugăm încercați din nou ");
    }

    public void showMessageDialog(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
    public void showPerfumeDetailsByName(String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        String[] columnNames = {
                "ID", "Nume", "Producator", "Pret", "Descriere"
        };

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < columnNames.length; i++) {
            JLabel label = new JLabel(columnNames[i] + ":");
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }

        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, "Detalii Parfum", JOptionPane.PLAIN_MESSAGE);
    }


    public void showPerfumeDetails(String title, String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            JLabel label = new JLabel(detail.substring(0, detail.indexOf(':') + 1));
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }


        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, title, JOptionPane.PLAIN_MESSAGE);
    }

    public void displayParfumList(Object[][] parfumList) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);

        for (Object[] row : parfumList) {
            tableModel.addRow(row);
        }
    }

}