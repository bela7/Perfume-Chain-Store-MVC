package Model;
import java.util.List;


public abstract class Persistent<T> {
    public abstract boolean create(T item);
    public abstract T read(int id);
    public abstract boolean update(T item);
    public abstract boolean delete(int id);
    public abstract List<T> getAll();
}
