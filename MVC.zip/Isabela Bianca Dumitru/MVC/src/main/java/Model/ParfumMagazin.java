package Model;
public class ParfumMagazin {
    private Parfum parfum;
    private Magazin magazin;
    private boolean disponibilitate;
    private int stoc;


    public ParfumMagazin() {
    }

    public ParfumMagazin(Parfum parfum, Magazin magazin, boolean disponibilitate, int stoc) {
        this.parfum = parfum;
        this.magazin = magazin;
        this.disponibilitate = disponibilitate;
        this.stoc = stoc;
    }
    public Parfum getParfum() {
        return parfum;
    }

    public void setParfum(Parfum parfum) {
        this.parfum = parfum;
    }


    public boolean isDisponibilitate() {
        return disponibilitate;
    }

    public void setDisponibilitate(boolean disponibilitate) {
        this.disponibilitate = disponibilitate;
    }

    public int getStoc() {
        return stoc;
    }

    public void setStoc(int stoc) {
        this.stoc = stoc;
    }
}
