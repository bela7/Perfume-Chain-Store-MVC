package Controller;

import Model.*;
import View.ManagerView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ResourceBundle;

public class ManagerController {
    private ManagerView view;
    private ParfumPersistent parfumPersistent;
    private MagazinPersistent magazinPersistent;
    private LanguageController languageController;

    public ManagerController() {
        this.parfumPersistent = new ParfumPersistent();
        this.magazinPersistent = new MagazinPersistent();
        this.languageController = new LanguageController();
    }

    public void setView(ManagerView view) {
        this.view = view;
        setupListeners();
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
        displayProducators();
        displayParfumList();
    }

    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        view.setTitle(rb.getString("managerTitle"));
        view.getBtnViewDetails().setText(rb.getString("vizualizeazaDetaliileButton"));
        view.getBtnCauta().setText(rb.getString("cautaButton"));
        view.getLblMagazin().setText(rb.getString("magazin"));
        view.getLblSortareNume().setText(rb.getString("sortareNume"));
        view.getLblSortarePret().setText(rb.getString("sortarePret"));
        view.getLblCautaDupaNume().setText(rb.getString("cautaNume"));
        view.getBtnFiltreaza().setText(rb.getString("filtreazaButton"));
        view.getLblPretMinim().setText(rb.getString("pretMinimLabel"));
        view.getLblPretMaxim().setText(rb.getString("pretMaximLabel"));
        view.getLblProducator().setText(rb.getString("producatorLabel"));
        view.getLblDisponibilitate().setText(rb.getString("disponibilitateLabel"));
        view.getChckbxDisponibil().setText(rb.getString("disponibilCheckbox"));

        String[] columnNames = new String[] {
                rb.getString("idParfumLabel"),
                rb.getString("denumireLabel"),
                rb.getString("producatorLabel"),
                rb.getString("pretLabel"),
                rb.getString("descriereLabel"),
                rb.getString("stocLabel")
        };
        DefaultTableModel model = (DefaultTableModel) view.getTable().getModel();
        model.setColumnIdentifiers(columnNames);
        updateComboBoxSortarePret();
        updateComboBoxSortareNume();

    }

    public void showView(String user) {
        view = new ManagerView(user);
        setView(view);
        view.setVisible(true);
        view.setTitle("Manager - " + user);
        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));
        displayMagazinNames();
        updateComboBoxSortarePret();
        updateComboBoxSortareNume();
        displayParfumList();
        displayProducators();
        initializeSortingLabels();
    }



    private void setupListeners() {

        view.getComboBoxMagazin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayParfumList();
            }
        });


        view.getComboBoxSortareNume().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortParfumsByName();
            }
        });

        view.getComboBoxSortarePret().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortParfumsByPrice();
            }
        });

        view.getBtnCauta().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSearchParfumByName();
            }
        });

        view.getBtnViewDetails().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = view.getTable().getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = view.getRowData(view.getTable(), selectedRow);
                    String[] formattedDetails = getFormattedPerfumeDetails(rowData);
                    view.showPerfumeDetails(formattedDetails[0], formattedDetails[1]);
                } else {
                    view.showMessageDialog(getLocalizedMessage("notSelectedParfumMessage"));
                }
            }
        });

        view.getBtnFiltreaza().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleFilterParfums();
            }
        });

    }


    public String getLocalizedMessage(String key) {
        ResourceBundle rb = view.getResourceBundle();
        return rb.getString(key);
    }

    public void displayMagazinNames() {
        List<Magazin> magazine = magazinPersistent.getAll();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        comboBoxMagazin.removeAllItems();

        for (Magazin magazin : magazine) {
            comboBoxMagazin.addItem(magazin.getNume());
        }
        displayParfumList();
    }

    public String[] getFormattedPerfumeDetails(Object[] rowData) {
        ResourceBundle rb = view.getResourceBundle();
        String title = rb.getString("detaliiParfumTitle");
        String details = String.format(
                "%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s",
                rb.getString("idParfumLabel"), rowData[0],
                rb.getString("denumireLabel"), rowData[1],
                rb.getString("producatorLabel"), rowData[2],
                rb.getString("pretLabel"), rowData[3],
                rb.getString("descriereLabel"), rowData[4],
                rb.getString("stocLabel"), rowData[5]
        );
        return new String[]{title, details};
    }



    public boolean isSortByPriceAscending() {

        JComboBox<String> comboBoxSortarePret = view.getComboBoxSortarePret();

        return comboBoxSortarePret.getSelectedItem().equals("Crescător");
    }

    public boolean isSortByNameAscending() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        String selectedItem = (String) comboBoxSortareNume.getSelectedItem();
        if (selectedItem == null) {
            return true; // Default to ascending if no item is selected
        }
        return selectedItem.equals(view.getResourceBundle().getString("crescator"));
    }


    public void updateComboBoxSortarePret() {
        JComboBox<String> comboBoxSortarePret = view.getComboBoxSortarePret();
        ActionListener[] listeners = comboBoxSortarePret.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxSortarePret.removeActionListener(listener);
        }
        comboBoxSortarePret.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxSortarePret.addItem(rb.getString("crescator"));
        comboBoxSortarePret.addItem(rb.getString("descrescator"));

        for (ActionListener listener : listeners) {
            comboBoxSortarePret.addActionListener(listener);
        }
    }

    public void updateComboBoxSortareNume() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        ActionListener[] listeners = comboBoxSortareNume.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxSortareNume.removeActionListener(listener);
        }
        comboBoxSortareNume.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxSortareNume.addItem(rb.getString("crescator"));
        comboBoxSortareNume.addItem(rb.getString("descrescator"));

        for (ActionListener listener : listeners) {
            comboBoxSortareNume.addActionListener(listener);
        }
    }

    public void displayProducators() {
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);
        List<String> producators = parfumPersistent.getAllProducators(idMagazin);
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        comboBoxProducator.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            Locale romanianLocale = new Locale("ro", "RO");
            rb = ResourceBundle.getBundle("LanguageBundle", romanianLocale);
        }

        comboBoxProducator.addItem(rb.getString("totiProducatorii"));

        for (String producator : producators) {
            comboBoxProducator.addItem(producator);
        }
        displayParfumList();
    }


    public String getSelectedProducator() {
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        if (comboBoxProducator.getSelectedIndex() > 0) {
            return (String) comboBoxProducator.getSelectedItem();
        }
        return "";
    }

    public String getPriceMin() {
        return view.getTextFieldPretMin().getText().trim();
    }


    public String getEnteredParfumName() {

        return view.getTextFieldCautaDupaNume().getText();
    }

    public String getPriceMax() {
        return view.getTextFieldPretMax().getText().trim();
    }


    public boolean isDisponibilSelected() {
        JCheckBox chckbxDisponibil = view.getChckbxDisponibil();
        return chckbxDisponibil.isSelected();
    }

    public void handleFilterParfums() {
        Double priceMin = null;
        Double priceMax = null;
        String producator = null;
        Boolean disponibil = null;

        String priceMinText = getPriceMin();
        String priceMaxText = getPriceMax();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);


        if (!priceMinText.isEmpty()) {
            priceMin = Double.parseDouble(priceMinText);
        }

        if (!priceMaxText.isEmpty()) {
            priceMax = Double.parseDouble(priceMaxText);
        }

        if (!getSelectedProducator().isEmpty()) {
            producator = getSelectedProducator();
        }

        if (isDisponibilSelected()) {
            disponibil = isDisponibilSelected();
        }

        Locale currentLocale = view.getLocale();
        String language = currentLocale.getLanguage();

        List<ParfumMagazin> filteredParfums = parfumPersistent.filterParfums(idMagazin, priceMin, priceMax, producator, disponibil, language);

        updateParfumList(filteredParfums);
    }

    public void handleSortParfumsByName() {
        boolean ascending = isSortByNameAscending();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            Locale romanianLocale = new Locale("ro", "RO");
            rb = ResourceBundle.getBundle("LanguageBundle", romanianLocale);
        }

        Locale currentLocale = rb.getLocale();
        String language = currentLocale.getLanguage();

        List<ParfumMagazin> sortedParfums = parfumPersistent.getSortedParfumsByName(idMagazin, ascending, language);

        updateParfumList(sortedParfums);
    }


    public void handleSortParfumsByPrice() {
        boolean ascending = isSortByPriceAscending();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Locale currentLocale = view.getLocale();
        String language;
        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        List<ParfumMagazin> sortedParfums = parfumPersistent.getSortedParfumsByPrice(idMagazin, ascending, language);


        updateParfumList(sortedParfums);
    }

    public void initializeSortingLabels() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            Locale romanianLocale = new Locale("ro", "RO");
            rb = ResourceBundle.getBundle("LanguageBundle", romanianLocale);
        }

        comboBoxSortareNume.removeAllItems();
        comboBoxSortareNume.addItem(rb.getString("crescator"));
        comboBoxSortareNume.addItem(rb.getString("descrescator"));
    }


    public void handleSearchParfumByName() {
        String parfumName = getEnteredParfumName();
        Parfum parfum = parfumPersistent.readByName(parfumName);

        if (parfum != null) {
            String parfumDetails = String.format("ID: %d\nNume: %s\nProducator: %s\nPret: %.2f\nDescriere: %s",
                    parfum.getIdParfum(), parfum.getNume(),
                    parfum.getProducator(), parfum.getPret(), parfum.getDescriere());
            view.showPerfumeDetailsByName(parfumDetails);
        } else {
            view.showMessageDialog(getLocalizedMessage("notFound"));
        }
    }

    public int getMagazinIdByName(String selectedMagazinName) {
        List<Magazin> magazine = magazinPersistent.getAll();

        for (Magazin magazin : magazine) {
            if (magazin.getNume().equals(selectedMagazinName)) {
                return magazin.getIdMagazin();
            }
        }

        return -1;
    }

    public void displayParfumList() {
        String language;
        Locale currentLocale = languageController.getCurrentLocale();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }
        List<ParfumMagazin> parfumuriMagazin = parfumPersistent.getAllParfumuriForMagazin(idMagazin, language);

        // Transformare în tabel
        Object[][] parfumList = new Object[parfumuriMagazin.size()][6];
        for (int i = 0; i < parfumuriMagazin.size(); i++) {
            ParfumMagazin pm = parfumuriMagazin.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        JTable table = view.getTable();
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);

        for (Object[] row : parfumList) {
            tableModel.addRow(row);
        }
    }


    private void updateParfumList(List<ParfumMagazin> parfumMagazinList) {
        Object[][] parfumList = new Object[parfumMagazinList.size()][6];
        for (int i = 0; i < parfumMagazinList.size(); i++) {
            ParfumMagazin pm = parfumMagazinList.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        view.displayParfumList(parfumList);
    }


}

