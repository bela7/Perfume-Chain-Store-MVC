package Controller;

import Model.*;
import View.AngajatView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class AngajatController {
    private AngajatView view;
    private ParfumPersistent parfumPersistent;
    private ParfumMagazinPersistent parfumMagazinPersistent;
    private LanguageController languageController;
    private int idMagazin;


    public AngajatController() {
        this.parfumPersistent = new ParfumPersistent();
        this.parfumMagazinPersistent = new ParfumMagazinPersistent();
        this.languageController = new LanguageController();
    }

    public void setView(AngajatView view) {
        this.view = view;
        setupListeners();
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
        displayProducators();
        displayParfumList();
    }



    public void showView(String user, int idMagazin) {
        this.idMagazin=idMagazin;
        view = new AngajatView(user,idMagazin);
        setView(view);
        view.setVisible(true);
        view.setTitle("Angajat - " + user);
        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));
        displayParfumList();
        displayProducators();

    }


    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        view.setTitle(rb.getString("managerTitle"));
        view.getLblIdParfum().setText(rb.getString("idParfumLabel"));
        view.getLblStoc().setText(rb.getString("stocLabel"));
        view.getBtnAdaugaParfum().setText(rb.getString("adaugaParfumButton"));
        view.getBtnActualizeazaParfum().setText(rb.getString("actualizeazaParfumButton"));
        view.getBtnViewDetails().setText(rb.getString("vizualizeazaDetaliileButton"));
        view.getBtnStergeParfum().setText(rb.getString("stergeParfumButton"));
        view.getBtnAdaugaParfumNou().setText(rb.getString("adaugaParfumNouButton"));
        view.getBtnFiltreaza().setText(rb.getString("filtreazaButton"));
        view.getLblPretMinim().setText(rb.getString("pretMinimLabel"));
        view.getLblPretMaxim().setText(rb.getString("pretMaximLabel"));
        view.getLblProducator().setText(rb.getString("producatorLabel"));
        view.getLblDisponibilitate().setText(rb.getString("disponibilitateLabel"));
        view.getChckbxDisponibil().setText(rb.getString("disponibilCheckbox"));


        String[] columnNames = new String[] {
                rb.getString("idParfumLabel"),
                rb.getString("denumireLabel"),
                rb.getString("producatorLabel"),
                rb.getString("pretLabel"),
                rb.getString("descriereLabel"),
                rb.getString("stocLabel")
        };
        DefaultTableModel model = (DefaultTableModel) view.getTable().getModel();
        model.setColumnIdentifiers(columnNames);
        updateAddParfumFrameLabels();

    }


    private void updateAddParfumFrameLabels() {
        ResourceBundle rb = view.getResourceBundle();

        view.getAddParfumFrame().setTitle(rb.getString("adaugaParfumNouButton"));

        JLabel lblIdParfumAdd = view.getLblIdParfumAdd();
        if (lblIdParfumAdd != null) {
            lblIdParfumAdd.setText(rb.getString("idParfumLabel"));
        }

        JLabel lblNumeAdd = view.getLblNumeAdd();
        if (lblNumeAdd != null) {
            lblNumeAdd.setText(rb.getString("denumireLabel"));
        }

        JLabel lblProducatorAdd = view.getLblProducatorAdd();
        if (lblProducatorAdd != null) {
            lblProducatorAdd.setText(rb.getString("producatorLabel"));
        }

        JLabel lblPretAdd = view.getLblPretAdd();
        if (lblPretAdd != null) {
            lblPretAdd.setText(rb.getString("pretLabel"));
        }

        JLabel lblDescriereAdd = view.getLblDescriereAdd();
        if (lblDescriereAdd != null) {
            lblDescriereAdd.setText(rb.getString("descriereLabel"));
        }

        JLabel lblStocAdd = view.getLblStocAdd();
        if (lblStocAdd != null) {
            lblStocAdd.setText(rb.getString("stocLabel"));
        }

        JButton btnSubmit = view.getBtnSubmit();
        if (btnSubmit != null) {
            btnSubmit.setText(rb.getString("adaugaParfumNouButton"));
        }

        JFrame addParfumFrame = view.getAddParfumFrame();
        if (addParfumFrame != null) {
            addParfumFrame.revalidate();
            addParfumFrame.repaint();
        }
    }



    public void addSubmitButtonListener(ActionListener listener) {
        if (view.getBtnSubmit() != null) {
        view.getBtnSubmit().addActionListener(listener);
    }}


    private void setupListeners() {

        view.getBtnAdaugaParfum().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                addParfum();
            }
        });


        view.getBtnActualizeazaParfum().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                updateParfum();
            }
        });

        view.getBtnStergeParfum().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                deleteParfum();
            }
        });

        view.getBtnViewDetails().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = view.getTable().getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = view.getRowData(view.getTable(), selectedRow);
                    String[] formattedDetails = getFormattedPerfumeDetails(rowData);
                    view.showPerfumeDetails(formattedDetails[0], formattedDetails[1]);
                } else {
                    view.showMessageDialog(getLocalizedMessage("notSelectedParfumMessage"));
                }
            }
        });



        view.getBtnAdaugaParfumNou().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view.showAddParfumFrame();
                updateAddParfumFrameLabels();
                addSubmitButtonListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        addNewParfum();
                        view.disposeAddParfumFrame();
                    }
                });
            }
        });


        view.getBtnFiltreaza().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button Filtreaza clicked");
                handleFilterParfums();
            }
        });


    }

    public String getSelectedProducator() {
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        if (comboBoxProducator.getSelectedIndex() > 0) {
            return (String) comboBoxProducator.getSelectedItem();
        }
        return "";
    }

    public String[] getFormattedPerfumeDetails(Object[] rowData) {
        ResourceBundle rb = view.getResourceBundle();
        String title = rb.getString("detaliiParfumTitle");
        String details = String.format(
                "%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s",
                rb.getString("idParfumLabel"), rowData[0],
                rb.getString("denumireLabel"), rowData[1],
                rb.getString("producatorLabel"), rowData[2],
                rb.getString("pretLabel"), rowData[3],
                rb.getString("descriereLabel"), rowData[4],
                rb.getString("stocLabel"), rowData[5]
        );
        return new String[]{title, details};
    }



    public int getIdParfum() {
        try {
            return Integer.parseInt(view.getTextFieldIdParfum().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }


    public int getStoc() {
        try {
            return Integer.parseInt(view.getTextFieldStoc().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }


    public int getNewIdParfum() {
        return Integer.parseInt(view.getTxtIdParfum().getText());
    }

    public String getNewNume() {
        return view.getTxtNume().getText();
    }

    public String getNewProducator() {
        return view.getTxtProducator().getText();
    }


    public double getNewPret() {
        return Double.parseDouble(view.getTxtPret().getText());
    }


    public String getNewDescriere() {
        return view.getTxtDescriere().getText();
    }


    public int getNewStoc() {
        return Integer.parseInt(view.getTxtStoc().getText());
    }


    public String getPriceMin() {
        return view.getTextFieldPretMin().getText().trim();
    }



    public String getPriceMax() {
        return view.getTextFieldPretMax().getText().trim();
    }

    public int getSelectedParfumId() {
        int selectedRow = view.getTable().getSelectedRow();
        if (selectedRow != -1) {
            return Integer.parseInt(view.getTable().getValueAt(selectedRow, 0).toString());
        } else {
            return -1;
        }
    }
    public boolean isDisponibilSelected() {
        JCheckBox chckbxDisponibil = view.getChckbxDisponibil();
        return chckbxDisponibil.isSelected();
    }

    public void handleFilterParfums() {
        System.out.println("handleFilterParfums called");
        Double priceMin = null;
        Double priceMax = null;
        String producator = null;
        Boolean disponibil = null;

        String priceMinText = getPriceMin();
        String priceMaxText = getPriceMax();


        if (!priceMinText.isEmpty()) {
            priceMin = Double.parseDouble(priceMinText);
        }

        if (!priceMaxText.isEmpty()) {
            priceMax = Double.parseDouble(priceMaxText);
        }

        if (!getSelectedProducator().isEmpty()) {
            producator = getSelectedProducator();
        }

        if (isDisponibilSelected()) {
            disponibil = isDisponibilSelected();
        }


        Locale currentLocale = view.getLocale();
        String language = currentLocale.getLanguage();

        List<ParfumMagazin> filteredParfums = parfumPersistent.filterParfums(idMagazin, priceMin, priceMax, producator, disponibil, language);

        updateParfumList(filteredParfums);
    }

    public String getLocalizedMessage(String key) {
        ResourceBundle rb = view.getResourceBundle();
        return rb.getString(key);
    }

    public void addParfum() {
        int idParfum = getIdParfum();
        int stoc = getStoc();

        if (idParfum != -1 && stoc != -1) {
            boolean success = parfumMagazinPersistent.createParfumMagazin(idParfum, idMagazin, stoc);
            if (success) {
                view.showMessageDialog(getLocalizedMessage("parfumAddedSuccessMessage"));
                displayParfumList();
            } else {
                view.showMessageDialog(getLocalizedMessage("failedToAddParfumMessage"));
            }
        } else {
            view.showMessageDialog(getLocalizedMessage("stocInvalid"));
        }
    }


    public void updateParfum() {
        int idParfum = getIdParfum();
        int stoc = getStoc();

        if (idParfum != -1 && stoc != -1) {
            boolean success = parfumMagazinPersistent.updateParfumMagazinStock(idParfum, idMagazin, stoc);
            if (success) {
                view.showMessageDialog(getLocalizedMessage("parfumUpdatedSuccessMessage"));
                displayParfumList();
            } else {
                view.showMessageDialog(getLocalizedMessage("failedToUpdateParfumMessage"));
            }
        }
    }

    public void deleteParfum() {
        int selectedParfumId = getSelectedParfumId();

        if (selectedParfumId == -1) {
            view.showMessageDialog(getLocalizedMessage("notSelectedParfumMessage"));
            return;
        }

        boolean success = parfumMagazinPersistent.deleteParfumMagazin(selectedParfumId,idMagazin);

        if (success) {
            view.showMessageDialog(getLocalizedMessage("parfumDeletedSuccessMessage"));
            displayParfumList();
        } else {
            view.showMessageDialog(getLocalizedMessage("failedToDeleteParfumMessage"));
        }
    }

    public void addNewParfum() {
        int idParfum = getNewIdParfum();
        String nume = getNewNume();
        String producator = getNewProducator();
        double pret = getNewPret();
        String descriere = getNewDescriere();
        int stoc = getNewStoc();
        if (idParfum != -1 && pret != -1 && stoc != -1 && !nume.isEmpty() && !producator.isEmpty() && !descriere.isEmpty()) {
            Parfum newParfum = new Parfum(idParfum, nume, producator, pret, descriere);
            ParfumPersistent parfumPersistent = new ParfumPersistent();
            boolean createdParfum = parfumPersistent.create(newParfum);

            if (createdParfum) {
                boolean createdParfumMagazin = parfumMagazinPersistent.createParfumMagazin(idParfum, idMagazin, stoc);
                boolean createdParfumTranslate = parfumPersistent.createParfumTranslate(idParfum, descriere);
                if (createdParfumMagazin && createdParfumTranslate) {
                    view.showMessageDialog(getLocalizedMessage("parfumAddedSuccessMessage"));
                    displayParfumList();
                } else {
                    view.showMessageDialog(getLocalizedMessage("failedToAddParfumMessage"));
                }
            } else {
                view.showMessageDialog(getLocalizedMessage("failedToAddParfumMessage"));
            }
        }
    }


    public void displayParfumList() {
        String language;
        Locale currentLocale = languageController.getCurrentLocale();
        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }
        List<ParfumMagazin> parfumuriMagazin = parfumPersistent.getAllParfumuriForMagazin(idMagazin, language);

        // Transformare în tabel
        Object[][] parfumList = new Object[parfumuriMagazin.size()][6];
        for (int i = 0; i < parfumuriMagazin.size(); i++) {
            ParfumMagazin pm = parfumuriMagazin.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        JTable table = view.getTable();
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);

        for (Object[] row : parfumList) {
            tableModel.addRow(row);
        }
    }

    public void displayProducators() {
        List<String> producators = parfumPersistent.getAllProducators(idMagazin);
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        comboBoxProducator.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            Locale romanianLocale = new Locale("ro", "RO");
            rb = ResourceBundle.getBundle("LanguageBundle", romanianLocale);
        }

        comboBoxProducator.addItem(rb.getString("totiProducatorii"));

        for (String producator : producators) {
            comboBoxProducator.addItem(producator);
        }
        displayParfumList();
    }


    private void updateParfumList(List<ParfumMagazin> parfumMagazinList) {
        Object[][] parfumList = new Object[parfumMagazinList.size()][6];
        for (int i = 0; i < parfumMagazinList.size(); i++) {
            ParfumMagazin pm = parfumMagazinList.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        view.displayParfumList(parfumList);
    }



}

