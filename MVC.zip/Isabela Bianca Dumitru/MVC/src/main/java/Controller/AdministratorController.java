package Controller;

import Model.Utilizator;
import Model.UtilizatorPersistent;
import View.AdministratorView;

import java.util.List;

import javax.swing.*;

import java.util.Locale;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;


public class AdministratorController {
    private AdministratorView view;
    private UtilizatorPersistent utilizatorPersistent;
    private LanguageController languageController;

    public AdministratorController() {
        this.utilizatorPersistent = new UtilizatorPersistent();
        this.languageController = new LanguageController();
    }

    public void setView(AdministratorView view) {
        this.view = view;
        setupListeners();
    }

    public void showView(String user) {
        view = new AdministratorView(user);
        setView(view);
        view.setVisible(true);
        view.setTitle("Administrator - " + user);
        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));

        displayUserList();
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
    }

    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        view.setTitle(rb.getString("adminTitle"));
        view.getUserIdLabel().setText(rb.getString("userIdLabel"));
        view.getUsernameLabel().setText(rb.getString("usernameLabel"));
        view.getPasswordLabel().setText(rb.getString("passwordLabel"));
        view.getRoleLabel().setText(rb.getString("roleLabel"));
        view.getIdMagazinLabel().setText(rb.getString("idMagazinLabel"));
        view.getAddUserButton().setText(rb.getString("addUserButton"));
        view.getDeleteUserButton().setText(rb.getString("deleteUserButton"));
        view.getUpdateUserButton().setText(rb.getString("updateUserButton"));
        view.getViewUserDetailsButton().setText(rb.getString("viewUserDetailsButton"));

        String[] translatedRoles = new String[]{
                rb.getString("roleAdministrator"),
                rb.getString("roleManager"),
                rb.getString("roleEmployee")
        };
        updateRoleComboBox(translatedRoles);

        String[] columnNames = new String[] {
                rb.getString("userIdLabel"),
                rb.getString("usernameLabel"),
                rb.getString("passwordLabel"),
                rb.getString("roleLabel"),
                rb.getString("idMagazinLabel")
        };
        DefaultTableModel model = (DefaultTableModel) view.getUserTable().getModel();
        model.setColumnIdentifiers(columnNames);
    }

    private void updateRoleComboBox(String[] translatedRoles) {
        JComboBox<String> roleComboBox = view.getRoleComboBox();
        String currentSelectedRole = (String) roleComboBox.getSelectedItem();
        DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) roleComboBox.getModel();
        model.removeAllElements();
        for (String role : translatedRoles) {
            model.addElement(role);
        }
        roleComboBox.setModel(model);
    }


    public int getUserId() {
        try {
            return Integer.parseInt(view.getUserIdField().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public String getUserName() {
        return view.getUserNameField().getText();
    }

    public String getPassword() {
        return view.getPasswordField().getText();
    }

    public String getRol() {
        return (String) view.getRolComboBox().getSelectedItem();
    }

    public int getIdMagazin() {
        try {
            return Integer.parseInt(view.getIdMagazinField().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public int getSelectedUserId() {
        int selectedRow = view.getUserTable().getSelectedRow();
        if (selectedRow != -1) {
            return Integer.parseInt(view.getUserTable().getValueAt(selectedRow, 0).toString());
        } else {
            return -1;
        }
    }

    public String getLocalizedMessage(String key) {
        ResourceBundle rb = view.getResourceBundle();
        return rb.getString(key);
    }

    private void setupListeners() {
        view.getAddUserButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addUser();
            }
        });

        view.getDeleteUserButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteUser();
            }
        });

        view.getUpdateUserButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateUser();
            }
        });

        view.getViewUserDetailsButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = view.getUserTable().getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = view.getRowData(selectedRow);
                    String userDetails = String.format(
                            "ID User: %s\nUsername: %s\nParola: %s\nRol: %s\nID Magazin: %s",
                            rowData[0], rowData[1], rowData[2], rowData[3], rowData[4]
                    );
                    view.showUserDetails(userDetails);
                } else {
                    view.showMessageDialog(getLocalizedMessage("selectUser"));
                }
            }
        });
    }

        public void addUser() {
                Utilizator utilizator = new Utilizator();
                int userId = getUserId();
                String username=getUserName();
                String rol = getRol();
                String parola= getPassword();
                int idMagazin= getIdMagazin();

                utilizator.setUserId(userId);
                utilizator.setUser(username);
                utilizator.setParola(parola);
                utilizator.setRol(rol);
                utilizator.setIdMagazin(idMagazin);

                boolean success = utilizatorPersistent.create(utilizator);

                if (success) {
                    view.showMessageDialog(getLocalizedMessage("userSuccess"));
                    displayUserList();
                } else {
                view.showMessageDialog(getLocalizedMessage("userFailed"));
                }
            }

        public void updateUser() {
                int selectedUserId = getSelectedUserId();

                if (selectedUserId == -1) {
                    view.showMessageDialog(getLocalizedMessage("selectUser"));
                    return;
                }

                Utilizator utilizator = new Utilizator();
                int userId = getUserId();
                String username=getUserName();
                String rol = getRol();
                String parola= getPassword();
                int idMagazin= getIdMagazin();

                utilizator.setUserId(userId);
                utilizator.setUser(username);
                utilizator.setParola(parola);
                utilizator.setRol(rol);
                utilizator.setIdMagazin(idMagazin);

                 boolean success = utilizatorPersistent.update(utilizator);

                if (success) {
                    view.showMessageDialog(getLocalizedMessage("updateUser"));
                    displayUserList();
                } else {
                    view.showMessageDialog(getLocalizedMessage("failedUpdate"));
                }
            }


        public void deleteUser() {
                int selectedUserId = getSelectedUserId();

                if (selectedUserId == -1) {
                    view.showMessageDialog(getLocalizedMessage("selectUser"));
                    return;
                }

                boolean success = utilizatorPersistent.delete(selectedUserId);

                if (success) {
                    view.showMessageDialog(getLocalizedMessage("deleteSuccess"));
                    displayUserList();
                } else {
                    view.showMessageDialog(getLocalizedMessage("failedDelete"));
                }
            }


        public void displayUserList() {
            List<Utilizator> utilizatori = utilizatorPersistent.getAll();
            Object[][] users = new Object[utilizatori.size()][5];
            for (int i = 0; i < utilizatori.size(); i++) {
                Utilizator utilizator = utilizatori.get(i);
                users[i][0] = utilizator.getUserId();
                users[i][1] = utilizator.getUser();
                users[i][2] = utilizator.getParola();
                users[i][3] = utilizator.getRol();
                users[i][4] = utilizator.getIdMagazin();
            }
            view.displayUsers(users);
        }




}
