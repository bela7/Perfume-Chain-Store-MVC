package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Model.Utilizator;
import Model.UtilizatorPersistent;
import View.LoginView;
import Model.Language;

import java.util.Locale;

import java.util.ResourceBundle;

public class LoginController {
    private LoginView view;
    private UtilizatorPersistent utilizatorPersistent;
    private LanguageController languageController;

    public LoginController(Language language) {
        Locale currentLocale = language.getCurrentLocale();
        this.view = new LoginView(currentLocale);
        this.utilizatorPersistent = new UtilizatorPersistent();
        this.languageController = new LanguageController();

        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));

        view.getBtnLogin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                autentificare();
            }
        });

        view.getBtnCancel().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        });
    }

    public void initialize() {
        view.setVisible(true);
    }

    public void autentificare() {
        String user = view.getUser().getText();
        String parola = String.valueOf(view.getPassword().getPassword());

        Utilizator utilizator = utilizatorPersistent.cautareUtilizator(user, parola);

        if (utilizator != null) {
            String rol = utilizator.getRol();
            int idMagazin = utilizator.getIdMagazin();

            if (rol.equalsIgnoreCase("administrator")) {
                AdministratorController adminController = new AdministratorController();
                adminController.showView(user);
            } else if (rol.equalsIgnoreCase("manager")) {
                ManagerController managerController = new ManagerController();
                managerController.showView(user);
            } else if (rol.equalsIgnoreCase("angajat")) {
                AngajatController angajatController = new AngajatController();
                angajatController.showView(user, idMagazin);
            }
        } else {
            view.mesajEroare();
        }
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
    }

    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        // Update labels, buttons, etc. with new language strings
        view.setTitle(rb.getString("loginTitle"));
        view.getLbUser().setText(rb.getString("usernameLabel"));
        view.getLbPassword().setText(rb.getString("passwordLabel"));
        view.getBtnLogin().setText(rb.getString("loginButton"));
        view.getBtnCancel().setText(rb.getString("cancelButton"));
    }
}
