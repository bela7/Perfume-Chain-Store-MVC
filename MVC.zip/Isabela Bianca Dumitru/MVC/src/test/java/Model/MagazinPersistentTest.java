package Model;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MagazinPersistentTest {

    private MagazinPersistent magazinPersistent;

    @BeforeEach
    void setUp() {
        try {
            DatabaseConnection.getConnection();
            magazinPersistent = new MagazinPersistent();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Nu se poate conecta la baza de date", e);
        }
    }

    @AfterEach
    void tearDown() {
        magazinPersistent = null;
    }

    @Test
    void testCreate() {
        Magazin newMagazin = new Magazin();
        newMagazin.setIdMagazin(100);
        newMagazin.setNume("testNume");
        newMagazin.setAdresa("testAdresa");

        assertTrue(magazinPersistent.create(newMagazin));
    }

    @Test
    void testRead() {
        int testMagazinId = 1;
        Magazin foundMagazin = magazinPersistent.read(testMagazinId);
        assertNotNull(foundMagazin);
        assertEquals(testMagazinId, foundMagazin.getIdMagazin());
    }

    @Test
    void testUpdate() {
        Magazin updatedMagazin = new Magazin();
        updatedMagazin.setIdMagazin(100);
        updatedMagazin.setNume("updatedTestNume");
        updatedMagazin.setAdresa("updatedTestAdresa");

        assertTrue(magazinPersistent.update(updatedMagazin));
    }

    @Test
    void testDelete() {
        int testMagazinId = 100;
        assertTrue(magazinPersistent.delete(testMagazinId));
    }

    @Test
    void testGetAll() {
        List<Magazin> magazine = magazinPersistent.getAll();
        assertNotNull(magazine);
        assertTrue(magazine.size() > 0);
    }
}
