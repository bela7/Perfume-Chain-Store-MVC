package Model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.sql.SQLException;


import static org.junit.jupiter.api.Assertions.*;

class UtilizatorPersistentTest {

    private UtilizatorPersistent utilizatorPersistent;

    @BeforeEach
    void setUp() {
        try {
            DatabaseConnection.getConnection();
            utilizatorPersistent = new UtilizatorPersistent();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Nu se poate conecta la baza de date", e);
        }

    }

    @AfterEach
    void tearDown() {
        utilizatorPersistent = null;
    }

    @Test
    void testCreate() {
        Utilizator newUtilizator = new Utilizator();
        newUtilizator.setUserId(99);
        newUtilizator.setUser("testUser");
        newUtilizator.setParola("testParola");
        newUtilizator.setRol("testRol");

        assertTrue(utilizatorPersistent.create(newUtilizator));
    }

    @Test
    void testRead() {
        int testUserId = 99;
        Utilizator foundUtilizator = utilizatorPersistent.read(testUserId);
        assertNotNull(foundUtilizator);
        assertEquals(testUserId, foundUtilizator.getUserId());
    }

    @Test
    void testUpdate() {
        Utilizator updatedUtilizator = new Utilizator();
        updatedUtilizator.setUserId(99);
        updatedUtilizator.setUser("updatedTestUser");
        updatedUtilizator.setParola("updatedTestParola");
        updatedUtilizator.setRol("updatedTestRol");

        assertTrue(utilizatorPersistent.update(updatedUtilizator));
    }

    @Test
    void testDelete() {
        int testUserId = 99;
        assertTrue(utilizatorPersistent.delete(testUserId));
    }
}
