package Model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.SQLException;

class ParfumMagazinPersistentTest {
    private ParfumMagazinPersistent parfumMagazinPersistent;

    @BeforeEach
    void setUp() {
        try {
            DatabaseConnection.getConnection();
            parfumMagazinPersistent = new ParfumMagazinPersistent();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to set up test environment due to database connection failure", e);
        }
    }


    @AfterEach
    void tearDown() {
        parfumMagazinPersistent = null;
    }

    @Test
    void testCreateParfumMagazin() {
        int idParfum = 1;
        int idMagazin = 1;
        int stoc = 10;
        assertTrue(parfumMagazinPersistent.createParfumMagazin(idParfum, idMagazin, stoc));
    }
    @Test
    void testUpdateParfumMagazinStock() {
        int idParfum = 1;
        int idMagazin = 1;
        int newStock = 30;

        assertTrue(parfumMagazinPersistent.updateParfumMagazinStock(idParfum, idMagazin, newStock));
    }

    @Test
    void testDeleteParfumMagazin() {
        int idParfum = 1;
        int idMagazin = 1;

        assertTrue(parfumMagazinPersistent.deleteParfumMagazin(idParfum, idMagazin));
    }


}
